<div class="row-fluid">
    {!! $this->widgets['dashboardContainer']->render() !!}
</div>
