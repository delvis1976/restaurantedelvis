<div class="row-fluid">
    {!! $this->widgets['manager']->render() !!}
</div>
