<a
    {!! $button->getAttributes() !!}
    tabindex="0"
>{!! $button->label ?: $button->name !!}</a>
