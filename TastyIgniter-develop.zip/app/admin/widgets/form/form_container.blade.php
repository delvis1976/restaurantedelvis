<div class="form-widget">
    {!! $this->makePartial('form/form') !!}
</div>
