<li class="nav-item">
    <span class="btn-location">
        <i class="fa fa-bank fa-fw visible-xs-inline-block"></i>
        <span class="text-nowrap hidden-xs"><strong>{{ $item->label }}</strong></span>
    </span>
</li>
