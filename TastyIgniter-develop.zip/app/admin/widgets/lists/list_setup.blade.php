<div class="modal fade" id="{{ $listId }}-setup-modal">
    <div id="{{ $listId }}-setup-modal-content">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <span class="spinner text-muted"><span class="ti-loading fa-3x fa-fw"></span></span>
                </div>
            </div>
        </div>
    </div>
</div>
