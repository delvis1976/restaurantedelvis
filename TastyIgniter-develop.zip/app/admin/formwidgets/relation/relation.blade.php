<div class="relation-widget">
    {!! $this->makePartial('~/app/admin/widgets/form/field_'.$field->type, ['field' => $field]) !!}
</div>
