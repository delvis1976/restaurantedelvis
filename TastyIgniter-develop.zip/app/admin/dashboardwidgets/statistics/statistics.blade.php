<div class="card-counter {{ $statsContext }}">
    <i class="stat-icon {{ $statsIcon }}"></i>
    <span class="stat-number">{{ $statsCount }}</span>
    <span class="stat-text">@lang($statsLabel)</span>
</div>
